## Running Server

> python3 app.py

Serving Flask app “dirName"

Environment: development

Debug mode: on

Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)

Restarting with stat

Debugger is active!

Debugger PIN: 855-212-761


Flask code base from TA: https://github.com/hawkeye154/d3_flask_tutorial

### Environment

Python 3.7.0
